﻿namespace language_model
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.CalculateProbabilityButton = new System.Windows.Forms.Button();
            this.txtInputText = new System.Windows.Forms.TextBox();
            this.lblProbability = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInputSentence = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CalculateProbabilityButton
            // 
            this.CalculateProbabilityButton.BackColor = System.Drawing.Color.Salmon;
            this.CalculateProbabilityButton.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CalculateProbabilityButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CalculateProbabilityButton.Location = new System.Drawing.Point(422, 511);
            this.CalculateProbabilityButton.Name = "CalculateProbabilityButton";
            this.CalculateProbabilityButton.Size = new System.Drawing.Size(203, 53);
            this.CalculateProbabilityButton.TabIndex = 0;
            this.CalculateProbabilityButton.Text = "UPLOUD AND MANAGE TEXT";
            this.CalculateProbabilityButton.UseVisualStyleBackColor = false;
            this.CalculateProbabilityButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtInputText
            // 
            this.txtInputText.Location = new System.Drawing.Point(186, 61);
            this.txtInputText.Multiline = true;
            this.txtInputText.Name = "txtInputText";
            this.txtInputText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtInputText.Size = new System.Drawing.Size(739, 244);
            this.txtInputText.TabIndex = 1;
            // 
            // lblProbability
            // 
            this.lblProbability.AutoSize = true;
            this.lblProbability.BackColor = System.Drawing.Color.SlateBlue;
            this.lblProbability.Font = new System.Drawing.Font("MV Boli", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProbability.ForeColor = System.Drawing.Color.Transparent;
            this.lblProbability.Location = new System.Drawing.Point(5, 404);
            this.lblProbability.Name = "lblProbability";
            this.lblProbability.Size = new System.Drawing.Size(264, 55);
            this.lblProbability.TabIndex = 3;
            this.lblProbability.Text = "ResultLabel";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Firebrick;
            this.label1.Location = new System.Drawing.Point(72, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(982, 34);
            this.label1.TabIndex = 4;
            this.label1.Text = "THIS IS A LANGUAGE MODEL THAT CAN RECEIVES A TEXT OF A  1000 WORDS OR MORE  AND F" +
    "INDS THE BI_GRAMS PROBABILITY\r\n OF EACH  SENTENCES RELATIVE TO THE TEXT THAT YOU" +
    " GIVE IT , WE HOPE YOU ENJOY IT :)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Firebrick;
            this.label2.Location = new System.Drawing.Point(12, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 34);
            this.label2.TabIndex = 5;
            this.label2.Text = "PLEASE ENTER YOUR\r\n LONG TEXT HERE";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtInputSentence
            // 
            this.txtInputSentence.Location = new System.Drawing.Point(186, 330);
            this.txtInputSentence.Multiline = true;
            this.txtInputSentence.Name = "txtInputSentence";
            this.txtInputSentence.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtInputSentence.Size = new System.Drawing.Size(739, 60);
            this.txtInputSentence.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("MV Boli", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Firebrick;
            this.label3.Location = new System.Drawing.Point(12, 332);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 34);
            this.label3.TabIndex = 7;
            this.label3.Text = "AND ENTER YOUR\r\n SENTENCE HERE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1110, 629);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtInputSentence);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblProbability);
            this.Controls.Add(this.txtInputText);
            this.Controls.Add(this.CalculateProbabilityButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "LANGUAGE MODEL";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CalculateProbabilityButton;
        private System.Windows.Forms.TextBox txtInputText;
        private System.Windows.Forms.Label lblProbability;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInputSentence;
        private System.Windows.Forms.Label label3;
    }
}

