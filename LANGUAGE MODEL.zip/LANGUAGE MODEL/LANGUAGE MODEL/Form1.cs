﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace LANGUAGE_MODEL
{
    public partial class Form1 : Form
    {
        Dictionary<string, int> biGramCounts = new Dictionary<string, int>();
        int totalWords = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateProbabilityButton_Click(object sender, EventArgs e)
        {
            string text = txtInputText.Text.ToLower();
            string sentence = txtInputSentence.Text.ToLower();

            string[] words = text.Split(new char[] { ' ', '.', ',', ';', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            totalWords = words.Length;

            for (int i = 0; i < words.Length - 1; i++)
            {
                string biGram = words[i] + " " + words[i + 1];
                if (biGramCounts.ContainsKey(biGram))
                {
                    biGramCounts[biGram]++;
                }
                else
                {
                    biGramCounts.Add(biGram, 1);
                }
            }

            string[] sentenceWords = sentence.Split(new char[] { ' ', '.', ',', ';', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            double sentenceProbability = 1.0;

            for (int i = 0; i < sentenceWords.Length - 1; i++)
            {
                string biGram = sentenceWords[i] + " " + sentenceWords[i + 1];
                if (biGramCounts.ContainsKey(biGram))
                {
                    double biGramProbability = (double)biGramCounts[biGram] / totalWords;
                    sentenceProbability *= biGramProbability;
                }
            }

            lblProbability.Text = $"Sentence Probability: {sentenceProbability}";

        }
    }
}
