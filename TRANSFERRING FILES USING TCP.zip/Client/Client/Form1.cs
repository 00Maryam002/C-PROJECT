﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;



namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void sendfile(String Filename)
        {
           
                FileInfo information = new FileInfo(Filename);
                if (information.Length > 1024 * 1024)
                {
                    MessageBox.Show(" file size exceeds the maximum limit ");
                    return;
                }
                byte[] Filenamebyte = Encoding.Unicode.GetBytes(information.Name);
                Socket senddfile = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
                IPEndPoint IPPOINT = new IPEndPoint(IPAddress.Parse(textBox1.Text), int.Parse(textBox2.Text));
                byte[] filedata = File.ReadAllBytes(Filename);
                byte[] filenamelength = BitConverter.GetBytes(Filenamebyte.Length);
                byte[] DataSend = new byte[4 + Filenamebyte.Length + filedata.Length];
                filenamelength.CopyTo(DataSend, 0);
                Filenamebyte.CopyTo(DataSend, 4);
                filedata.CopyTo(DataSend, 4 + Filenamebyte.Length);
            try
            {
                senddfile.Connect(IPPOINT);
                senddfile.Send(DataSend);
                senddfile.Close();
            }
            catch
            {
                MessageBox.Show(" ERROR ");
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }



        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled = textBox3.Text != "";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            sendfile(textBox3.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            OpenFileDialog OP = new OpenFileDialog();
            if (OP.ShowDialog() == DialogResult.OK) {
                textBox3.Text = OP.FileName;

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
