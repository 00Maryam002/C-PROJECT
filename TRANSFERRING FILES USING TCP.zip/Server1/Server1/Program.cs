﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.IO;
using System.Threading;
using System.Diagnostics;

namespace ConsoleApp1
{
    class Program
    {
        public static void doChat(Socket clientSocket, string n)
        {
            Console.WriteLine("Getting file....");
            byte[] clientData = new byte[1024 * 1024]; // Increased buffer size
            int receivedBytesLen = clientSocket.Receive(clientData);
            int fileNameLen = BitConverter.ToInt32(clientData, 0);
            string fileName = Encoding.UTF8.GetString(clientData, 4, fileNameLen); // Use UTF8 for non-ASCII characters

            
            foreach (char invalidChar in Path.GetInvalidFileNameChars())
            {
                fileName = fileName.Replace(invalidChar, '_');
            }

            string filePath = Path.Combine(Directory.GetCurrentDirectory(), fileName + "_" + n);

            BinaryWriter bWrite = new BinaryWriter(File.Open(filePath, FileMode.Create));
            bWrite.Write(clientData, 4 + fileNameLen, receivedBytesLen - 4 - fileNameLen);
            bWrite.Close();
            clientSocket.Close();

            Console.WriteLine("File received and saved at: " + filePath);

           
            ProcessStartInfo startInfo = new ProcessStartInfo("cmd.exe", "/c cd /d " + Path.GetDirectoryName(filePath));
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = true;
            Process.Start(startInfo);

         
            Console.WriteLine("File received and saved at: " + Path.GetDirectoryName(filePath));
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Enter server IP address: ");
            string serverIP = Console.ReadLine();

            Console.WriteLine("Enter server port number: ");
            int port = int.Parse(Console.ReadLine());

            IPAddress ipAddress = IPAddress.Parse(serverIP);

            Console.WriteLine("Starting TCP listener...");

            IPEndPoint ipEnd = new IPEndPoint(ipAddress, port);
            Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            serverSocket.Bind(ipEnd);

            int counter = 0;

            serverSocket.Listen(3004);

            Console.WriteLine(" >> Server Started");

            while (true)
            {
                counter += 1;

                Socket clientSocket = serverSocket.Accept();
                Console.WriteLine(" >> Client No:" + Convert.ToString(counter) + " started");

                new Thread(() => {
                    doChat(clientSocket, Convert.ToString(counter));
                }).Start();
            }
        }
    }
}